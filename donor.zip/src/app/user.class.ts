export class User {
    name: string;
    email: string;
    username: string;
    tel: string;
    password: string;
}
